
const root = document.getElementById('root')

render()

function render(){
    let tit = document.createElement('h1')
    tit.innerText = "Simulación de cambio de Pensum"
    root.appendChild(tit)

}